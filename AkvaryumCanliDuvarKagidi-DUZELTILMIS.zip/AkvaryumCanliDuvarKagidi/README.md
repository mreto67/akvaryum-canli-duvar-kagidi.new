# Canlı Akvaryum — Android Live Wallpaper

Gerçekçi tropikal akvaryum arka planı üzerinde çalışan, dokunmaya tepki veren Android canlı duvar kâğıdı.

## Özellikler

- Fotoğraf gerçekçiliğinde su altı arka planı
- Farklı boyut, renk ve yüzme davranışlarına sahip animasyonlu balıklar
- Ekrana dokunulduğunda yakındaki balıkların hızla uzaklaşması
- Dokunma noktasında genişleyen çok halkalı su dalgaları
- Yükselen, hafifçe salınan hava kabarcıkları
- Arka planla uyumlu hafif ışık huzmeleri
- Yalnızca duvar kâğıdı görünürken çalışan animasyon döngüsü
- Harici kütüphane veya çalışma zamanı internet bağlantısı gerektirmez

## Android sürümleri

- Minimum Android: 6.0 (API 23)
- Derleme SDK: 35
- Java/Kotlin bytecode hedefi: 17

## GitHub Actions ile APK üretimi

Bu kaynak proje `AkvaryumCanliDuvarKagidi/` klasörünün içindedir. Depodaki mevcut workflow ZIP dosyasını açıp aşağıdaki Gradle görevini çalıştırıyorsa aynı klasör adını koruyun:

```bash
gradle -p extracted/AkvaryumCanliDuvarKagidi assembleDebug
```

APK çıktısı:

```text
app/build/outputs/apk/debug/app-debug.apk
```

GitHub Actions workflow'unun artifact yükleme adımı bu dosyayı yüklemelidir. Build başarılı görünse bile APK'yı gerçek telefonda kurup duvar kâğıdı önizlemesini, dokunma etkileşimini ve pil tüketimini ayrıca kontrol edin.
