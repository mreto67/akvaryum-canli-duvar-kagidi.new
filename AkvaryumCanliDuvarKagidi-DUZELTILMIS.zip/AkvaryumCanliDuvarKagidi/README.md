# Akvaryum Canlı Duvar Kâğıdı (Android)

Android Live Wallpaper için Kotlin/Android Studio başlangıç projesi.

## Özellikler
- Dikey akvaryum arka planı (projeye ekli görsel)
- Canvas ile hareket eden balıklar ve yükselen kabarcıklar
- Canlı duvar kâğıdı önizlemesinde dokunulan yere doğru balıkların kaçışması
- Dokunma noktasında dalga halkaları
- Ekran görünür değilken animasyon döngüsünü durdurma

## APK oluşturma
1. Android Studio'da bu klasörü aç.
2. Gradle senkronizasyonunun tamamlanmasını bekle (JDK 17 önerilir; Android SDK Platform 35 gerekir).
3. **Build > Build APK(s)** seç.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
5. APK'yı telefona aktar ve kur. Android izin isterse bu kaynağa ait uygulama yüklemesine izin ver.
6. Uygulamayı açıp **Canlı duvar kâğıdını ayarla** düğmesine bas; önizleme ekranında dokunarak dene ve **Duvar kâğıdını ayarla** seçeneğini kullan.

## Notlar
- Bu kaynak proje burada derlenmiş APK değildir; Android SDK/Gradle ile Android Studio'da derlenmelidir.
- Android üreticisine göre ana ekran, kilit ekranı veya her ikisi için uygulama seçeneği değişebilir.
- Balıklar, arka plan görseline ek olarak Canvas üzerinde animasyonlu çizilir. Arka plandaki balıkların kendisi ayrı katmanlara ayrılmış değildir.
