package com.example.akvaryum

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Lightweight, touch-reactive aquarium renderer. No network or runtime permissions required. */
class AquariumWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AquariumEngine()

    private enum class Species { TETRA, GUPPY, ANGEL, CLOWNFISH }

    private data class Fish(
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        var size: Float,
        val bodyColor: Int,
        val finColor: Int,
        val species: Species,
        var phase: Float,
        var fleeSeconds: Float = 0f,
        var fleeX: Float = 0f,
        var fleeY: Float = 0f,
        val depth: Float
    )

    private data class Ripple(val x: Float, val y: Float, var age: Float = 0f, val life: Float = 1.25f)
    private data class Bubble(val x: Float, var y: Float, val radius: Float, val speed: Float, val drift: Float, val phase: Float)

    inner class AquariumEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val rnd = Random(System.nanoTime())
        private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val effectPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var background: Bitmap? = null
        private var visible = false
        private var widthPx = 1
        private var heightPx = 1
        private var lastFrameMs = System.currentTimeMillis()
        private var lastMoveRippleX = -10000f
        private var lastMoveRippleY = -10000f
        private val fish = mutableListOf<Fish>()
        private val ripples = mutableListOf<Ripple>()
        private val bubbles = mutableListOf<Bubble>()

        private val drawFrame = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrameNow()
                handler.postDelayed(this, 33L)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            background = BitmapFactory.decodeResource(resources, R.drawable.aquarium_background)
            createFish()
            repeat(24) {
                bubbles += Bubble(
                    x = rnd.nextFloat(),
                    y = rnd.nextFloat(),
                    radius = 1.2f + rnd.nextFloat() * 3.1f,
                    speed = 12f + rnd.nextFloat() * 34f,
                    drift = -5f + rnd.nextFloat() * 10f,
                    phase = rnd.nextFloat() * 6.28f
                )
            }
        }

        private fun createFish() {
            fish.clear()
            val palette = listOf(
                0xFF11C9E8.toInt() to 0xFFFF4C5C.toInt(),
                0xFFFFA52E.toInt() to 0xFFFFE9B8.toInt(),
                0xFFFFD66B.toInt() to 0xFFFF6C2F.toInt(),
                0xFF4BBCEB.toInt() to 0xFF174F9B.toInt(),
                0xFFF5F0DA.toInt() to 0xFF182C3B.toInt(),
                0xFF62E4CE.toInt() to 0xFF087F95.toInt(),
                0xFFFF779E.toInt() to 0xFFB82D64.toInt()
            )
            repeat(18) { index ->
                val pair = palette[index % palette.size]
                val depth = 0.42f + rnd.nextFloat() * 0.8f
                fish += Fish(
                    x = rnd.nextFloat(), y = 0.12f + rnd.nextFloat() * 0.76f,
                    vx = (0.025f + rnd.nextFloat() * 0.035f) * if (rnd.nextBoolean()) 1f else -1f,
                    vy = -0.004f + rnd.nextFloat() * 0.008f,
                    size = (0.018f + rnd.nextFloat() * 0.022f) * depth,
                    bodyColor = pair.first, finColor = pair.second,
                    species = when (index % 8) {
                        0, 5 -> Species.CLOWNFISH
                        1, 6 -> Species.ANGEL
                        2, 7 -> Species.GUPPY
                        else -> Species.TETRA
                    },
                    phase = rnd.nextFloat() * 6.28f,
                    depth = depth
                )
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            widthPx = width.coerceAtLeast(1)
            heightPx = height.coerceAtLeast(1)
            drawFrameNow()
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            handler.removeCallbacks(drawFrame)
            if (visible) {
                lastFrameMs = System.currentTimeMillis()
                handler.post(drawFrame)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawFrame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawFrame)
            background?.recycle()
            background = null
            super.onDestroy()
        }

        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastMoveRippleX = event.x
                    lastMoveRippleY = event.y
                    reactToTouch(event.x, event.y, strong = true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastMoveRippleX
                    val dy = event.y - lastMoveRippleY
                    if (hypot(dx, dy) > min(widthPx, heightPx) * 0.065f) {
                        lastMoveRippleX = event.x
                        lastMoveRippleY = event.y
                        ripples += Ripple(event.x, event.y, life = 0.9f)
                        reactToTouch(event.x, event.y, strong = false)
                    }
                }
            }
            super.onTouchEvent(event)
        }

        private fun reactToTouch(touchX: Float, touchY: Float, strong: Boolean) {
            ripples += Ripple(touchX, touchY)
            val radius = min(widthPx, heightPx) * if (strong) 0.26f else 0.16f
            fish.forEach { f ->
                val dx = f.x * widthPx - touchX
                val dy = f.y * heightPx - touchY
                val distance = hypot(dx, dy)
                if (distance < radius) {
                    val safeDistance = max(1f, distance)
                    val nx = dx / safeDistance
                    val ny = dy / safeDistance
                    // Add a small sideways component so fish scatter naturally rather than in straight spokes.
                    val side = if (f.phase % 2f > 1f) 0.32f else -0.32f
                    f.fleeX = (nx - ny * side).coerceIn(-1.25f, 1.25f)
                    f.fleeY = (ny + nx * side).coerceIn(-1.25f, 1.25f)
                    f.vx = f.fleeX * if (strong) 0.24f else 0.16f
                    f.vy = f.fleeY * if (strong) 0.18f else 0.12f
                    f.fleeSeconds = if (strong) 0.85f + rnd.nextFloat() * 0.55f else 0.35f
                }
            }
            drawFrameNow()
        }

        private fun drawFrameNow() {
            val holder: SurfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val c = canvas
                drawBackground(c)
                val now = System.currentTimeMillis()
                val dt = ((now - lastFrameMs) / 1000f).coerceIn(0f, 0.05f)
                lastFrameMs = now
                drawSoftLight(c, now)
                fish.sortedBy { it.depth }.forEach { f ->
                    updateFish(f, dt)
                    drawFish(c, f)
                }
                drawBubbles(c, dt, now)
                drawRipples(c, dt)
            } catch (_: Exception) {
                // A wallpaper surface may disappear while Android is switching screens.
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) { }
                }
            }
        }

        private fun drawBackground(c: Canvas) {
            val bg = background
            if (bg == null || bg.isRecycled) {
                c.drawColor(0xFF063B54.toInt())
                return
            }
            val scale = max(widthPx.toFloat() / bg.width, heightPx.toFloat() / bg.height)
            val bw = bg.width * scale
            val bh = bg.height * scale
            val dst = RectF((widthPx - bw) / 2f, (heightPx - bh) / 2f, (widthPx + bw) / 2f, (heightPx + bh) / 2f)
            bodyPaint.shader = null
            bodyPaint.alpha = 255
            c.drawBitmap(bg, null, dst, bodyPaint)
            // Slight blue veil keeps the scene coherent behind the animated fish.
            effectPaint.style = Paint.Style.FILL
            effectPaint.color = 0x1600253A
            c.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), effectPaint)
        }

        private fun drawSoftLight(c: Canvas, now: Long) {
            // Very subtle drifting rays, kept translucent so the photographic background stays visible.
            val phase = now / 3800f
            effectPaint.shader = LinearGradient(
                widthPx * (0.15f + 0.05f * sin(phase)), 0f,
                widthPx * (0.58f + 0.06f * cos(phase * 0.7f)), heightPx * 0.78f,
                intArrayOf(0x00C7F5FF, 0x123EEBFF, 0x003EEBFF), null, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), effectPaint)
            effectPaint.shader = null
        }

        private fun updateFish(f: Fish, dt: Float) {
            f.phase += dt * (2.4f + f.depth)
            if (f.fleeSeconds > 0f) {
                f.fleeSeconds = (f.fleeSeconds - dt).coerceAtLeast(0f)
                f.x += f.vx * dt
                f.y += f.vy * dt
                val damping = if (f.fleeSeconds < 0.22f) 0.90f else 0.985f
                f.vx *= damping
                f.vy *= damping
            } else {
                val preferredDirection = if (f.vx < 0f) -1f else 1f
                val desiredVx = preferredDirection * (0.032f + 0.012f * sin(f.phase * 0.27f))
                f.vx += (desiredVx - f.vx) * dt * 0.75f
                f.vy += (sin(f.phase * 0.65f) * 0.009f - f.vy) * dt * 0.55f
                f.x += f.vx * dt
                f.y += f.vy * dt
            }
            if (f.x < -0.12f) { f.x = 1.12f; f.vx = abs(f.vx).coerceAtLeast(0.012f) }
            if (f.x > 1.12f) { f.x = -0.12f; f.vx = -abs(f.vx).coerceAtLeast(0.012f) }
            if (f.y < 0.07f) { f.y = 0.07f; f.vy = abs(f.vy) * 0.65f }
            if (f.y > 0.91f) { f.y = 0.91f; f.vy = -abs(f.vy) * 0.65f }
        }

        private fun drawFish(c: Canvas, f: Fish) {
            val x = f.x * widthPx
            val y = f.y * heightPx
            val s = f.size * min(widthPx, heightPx)
            if (s < 7f) return
            val facing = if (f.vx < -0.002f) -1f else 1f
            val tailSwing = sin(f.phase * 3.8f) * s * 0.12f
            c.save()
            c.translate(x, y + sin(f.phase * 1.5f) * s * 0.035f)
            c.scale(facing, 1f)
            c.scale(s / 36f, s / 36f)

            val body = when (f.species) {
                Species.ANGEL -> RectF(-18f, -21f, 19f, 21f)
                Species.GUPPY -> RectF(-21f, -10f, 19f, 10f)
                Species.CLOWNFISH -> RectF(-20f, -12f, 20f, 12f)
                Species.TETRA -> RectF(-20f, -8f, 20f, 8f)
            }
            val tail = Path().apply {
                moveTo(-17f, 0f)
                when (f.species) {
                    Species.GUPPY -> { quadTo(-27f, -16f + tailSwing, -39f, -18f + tailSwing); quadTo(-33f, 0f, -39f, 18f + tailSwing); quadTo(-27f, 15f + tailSwing, -17f, 0f) }
                    Species.ANGEL -> { lineTo(-34f, -17f + tailSwing); lineTo(-30f, 0f); lineTo(-34f, 17f + tailSwing); close() }
                    else -> { lineTo(-34f, -13f + tailSwing); lineTo(-32f, 0f); lineTo(-34f, 13f + tailSwing); close() }
                }
            }
            bodyPaint.shader = LinearGradient(-18f, -15f, 18f, 16f, intArrayOf(lighten(f.bodyColor), f.bodyColor, 0xFF102C3B.toInt()), null, Shader.TileMode.CLAMP)
            c.drawPath(tail, bodyPaint)
            bodyPaint.shader = null
            bodyPaint.color = f.finColor
            bodyPaint.alpha = 218
            val dorsal = Path().apply {
                moveTo(-12f, -8f); quadTo(-3f, -23f, 9f, -10f); quadTo(0f, -12f, -12f, -8f); close()
            }
            val ventral = Path().apply {
                moveTo(-8f, 8f); quadTo(2f, 20f, 10f, 9f); quadTo(1f, 12f, -8f, 8f); close()
            }
            c.drawPath(dorsal, bodyPaint)
            c.drawPath(ventral, bodyPaint)
            bodyPaint.alpha = 255
            bodyPaint.shader = LinearGradient(-18f, -14f, 18f, 12f, intArrayOf(lighten(f.bodyColor), f.bodyColor, darken(f.bodyColor)), null, Shader.TileMode.CLAMP)
            c.drawOval(body, bodyPaint)
            bodyPaint.shader = null

            // Species markings make the fish more recognizable at phone size.
            when (f.species) {
                Species.CLOWNFISH -> {
                    detailPaint.color = 0xFFF9F4E7.toInt()
                    detailPaint.style = Paint.Style.STROKE
                    detailPaint.strokeWidth = 3.4f
                    c.drawLine(-7f, -11f, -7f, 11f, detailPaint)
                    c.drawLine(7f, -11f, 7f, 11f, detailPaint)
                    detailPaint.style = Paint.Style.FILL
                    detailPaint.color = 0xAA182C3B.toInt()
                    c.drawLine(-9f, -10f, -9f, 10f, detailPaint)
                    c.drawLine(9f, -10f, 9f, 10f, detailPaint)
                }
                Species.TETRA -> {
                    detailPaint.color = 0xFF1C5FA5.toInt()
                    detailPaint.strokeWidth = 2.6f
                    c.drawLine(-12f, 1f, 12f, 1f, detailPaint)
                    detailPaint.color = 0xFFE94C63.toInt()
                    c.drawLine(-4f, 4f, 13f, 4f, detailPaint)
                }
                Species.ANGEL -> {
                    detailPaint.color = 0xCC172B38.toInt()
                    detailPaint.strokeWidth = 3f
                    c.drawLine(-7f, -17f, -3f, 17f, detailPaint)
                    c.drawLine(5f, -18f, 8f, 17f, detailPaint)
                }
                Species.GUPPY -> {
                    detailPaint.color = 0xAAFFFFFF.toInt()
                    detailPaint.strokeWidth = 1.3f
                    c.drawLine(-30f, -10f + tailSwing, -21f, 0f, detailPaint)
                    c.drawLine(-30f, 10f + tailSwing, -21f, 0f, detailPaint)
                }
            }
            // Gill arc, reflective highlight and eye.
            detailPaint.style = Paint.Style.STROKE
            detailPaint.strokeWidth = 1.15f
            detailPaint.color = 0x7A173044
            c.drawArc(RectF(7f, -6f, 14f, 7f), -80f, 160f, false, detailPaint)
            detailPaint.style = Paint.Style.FILL
            bodyPaint.shader = LinearGradient(-4f, -12f, 5f, 1f, 0x99FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawOval(RectF(-4f, -10f, 8f, -2f), bodyPaint)
            bodyPaint.shader = null
            c.drawCircle(13f, -3f, 3.2f, detailPaint.apply { color = 0xFFFDFDF7.toInt() })
            c.drawCircle(14f, -3f, 1.75f, detailPaint.apply { color = 0xFF071B25.toInt() })
            c.drawCircle(14.5f, -3.6f, 0.55f, detailPaint.apply { color = Color.WHITE })
            c.restore()
        }

        private fun drawBubbles(c: Canvas, dt: Float, now: Long) {
            bubbles.forEach { b ->
                b.y -= (b.speed / heightPx) * dt
                if (b.y < -0.03f) b.y = 1.03f
                val x = b.x * widthPx + sin(now / 950f + b.phase) * b.drift
                val y = b.y * heightPx
                effectPaint.style = Paint.Style.STROKE
                effectPaint.strokeWidth = max(0.8f, b.radius * 0.23f)
                effectPaint.color = 0x9AD9F8FF.toInt()
                c.drawCircle(x, y, b.radius, effectPaint)
                effectPaint.style = Paint.Style.FILL
                effectPaint.color = 0x88FFFFFF.toInt()
                c.drawCircle(x - b.radius * 0.28f, y - b.radius * 0.32f, max(0.6f, b.radius * 0.18f), effectPaint)
            }
        }

        private fun drawRipples(c: Canvas, dt: Float) {
            val iterator = ripples.iterator()
            while (iterator.hasNext()) {
                val ripple = iterator.next()
                ripple.age += dt
                if (ripple.age >= ripple.life) { iterator.remove(); continue }
                val progress = ripple.age / ripple.life
                val alpha = ((1f - progress) * 175f).toInt().coerceIn(0, 175)
                val baseRadius = min(widthPx, heightPx) * (0.018f + progress * 0.19f)
                effectPaint.style = Paint.Style.STROKE
                effectPaint.strokeWidth = max(1f, min(widthPx, heightPx) * 0.0022f * (1f - progress * 0.45f))
                effectPaint.color = Color.argb(alpha, 176, 239, 255)
                c.drawCircle(ripple.x, ripple.y, baseRadius, effectPaint)
                c.drawCircle(ripple.x, ripple.y, baseRadius * 0.67f, effectPaint)
                c.drawCircle(ripple.x, ripple.y, baseRadius * 0.34f, effectPaint)
                effectPaint.style = Paint.Style.FILL
            }
        }

        private fun lighten(color: Int): Int = Color.rgb(
            min(255, (Color.red(color) * 1.28f).toInt()),
            min(255, (Color.green(color) * 1.28f).toInt()),
            min(255, (Color.blue(color) * 1.28f).toInt())
        )

        private fun darken(color: Int): Int = Color.rgb(
            (Color.red(color) * 0.48f).toInt(),
            (Color.green(color) * 0.48f).toInt(),
            (Color.blue(color) * 0.48f).toInt()
        )
    }
}
