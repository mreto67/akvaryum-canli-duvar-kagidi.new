package com.example.akvaryum

import android.graphics.*
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import kotlin.math.*
import kotlin.random.Random

class AquariumWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AquariumEngine()

    private data class Fish(
        var x: Float, var y: Float, var speed: Float, var size: Float,
        var color: Int, var phase: Float,
        var fleeX: Float = 0f, var fleeY: Float = 0f, var flee: Int = 0
    )
    private data class Ripple(val x: Float, val y: Float, var age: Float = 0f)

    inner class AquariumEngine : Engine() {
        private val handler = android.os.Handler(mainLooper)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var background: Bitmap? = null
        private var visible = false
        private var w = 1
        private var h = 1
        private var last = System.currentTimeMillis()
        private val rnd = Random(System.nanoTime())
        private val fish = mutableListOf<Fish>()
        private val ripples = mutableListOf<Ripple>()
        private val colors = intArrayOf(0xFFFF8A22.toInt(), 0xFFFFD166.toInt(), 0xFFFAFAF2.toInt(), 0xFF28D7E5.toInt(), 0xFFFF5C83.toInt(), 0xFF8BE36A.toInt())
        private val drawFrame = object : Runnable { override fun run() { draw(); if (visible) handler.postDelayed(this, 33L) } }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            background = BitmapFactory.decodeResource(resources, R.drawable.aquarium_background)
            repeat(24) {
                fish += Fish(rnd.nextFloat(), rnd.nextFloat(), (0.018f + rnd.nextFloat() * 0.045f), 0.012f + rnd.nextFloat() * 0.022f, colors[rnd.nextInt(colors.size)], rnd.nextFloat() * 6.28f)
            }
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { super.onSurfaceChanged(holder, format, width, height); w = width.coerceAtLeast(1); h = height.coerceAtLeast(1); draw() }
        override fun onVisibilityChanged(visibleNow: Boolean) { visible = visibleNow; handler.removeCallbacks(drawFrame); if (visible) handler.post(drawFrame) }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; handler.removeCallbacks(drawFrame); super.onSurfaceDestroyed(holder) }
        override fun onTouchEvent(event: MotionEvent) {
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                val tx = event.x / w; val ty = event.y / h
                ripples += Ripple(event.x, event.y)
                fish.forEach { f ->
                    val dx = f.x * w - event.x; val dy = f.y * h - event.y
                    val d = hypot(dx, dy)
                    if (d < min(w, h) * 0.22f) {
                        val inv = 1f / max(1f, d)
                        f.fleeX = (dx * inv * 0.65f).coerceIn(-0.7f, 0.7f)
                        f.fleeY = (dy * inv * 0.65f).coerceIn(-0.7f, 0.7f)
                        f.flee = 42
                    }
                }
                // Keep ripple origin tied to the exact touch point; tx/ty are intentionally normalized above.
                draw()
            }
            super.onTouchEvent(event)
        }
        private fun draw() {
            val holder: SurfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val c = canvas
                val bg = background
                if (bg != null) {
                    val scale = max(w.toFloat() / bg.width, h.toFloat() / bg.height)
                    val bw = bg.width * scale; val bh = bg.height * scale
                    val dst = RectF((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
                    c.drawBitmap(bg, null, dst, paint)
                } else c.drawColor(0xFF063B54.toInt())
                val now = System.currentTimeMillis(); val dt = ((now - last) / 1000f).coerceIn(0f, 0.06f); last = now
                fish.forEachIndexed { i, f ->
                    f.phase += dt * 3f
                    if (f.flee > 0) { f.x += f.fleeX * dt * 1.6f; f.y += f.fleeY * dt * 1.6f; f.flee-- }
                    else { f.x += cos(f.phase * 0.55f + i) * f.speed * dt; f.y += sin(f.phase + i * 0.7f) * f.speed * dt * 0.45f }
                    if (f.x < -0.08f) f.x = 1.08f; if (f.x > 1.08f) f.x = -0.08f
                    if (f.y < 0.04f) f.y = 0.94f; if (f.y > 0.96f) f.y = 0.06f
                    drawFish(c, f)
                }
                val it = ripples.iterator()
                while (it.hasNext()) {
                    val r = it.next(); r.age += dt
                    if (r.age > 1.1f) { it.remove(); continue }
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f
                    paint.color = Color.argb(((1f - r.age / 1.1f) * 180).toInt(), 190, 246, 255)
                    val radius = 12f + r.age * min(w, h) * 0.18f
                    c.drawCircle(r.x, r.y, radius, paint); c.drawCircle(r.x, r.y, radius * 0.62f, paint)
                    paint.style = Paint.Style.FILL
                }
                // Ambient bubbles
                for (i in 0 until 14) {
                    val x = ((i * 79f + now * (0.008f + i % 3 * 0.003f)) % w)
                    val y = h - ((now * (0.018f + i % 4 * 0.008f) + i * 117f) % h)
                    paint.color = 0x669CEEFF; paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f
                    c.drawCircle(x, y, 2.5f + i % 3, paint); paint.style = Paint.Style.FILL
                }
            } catch (_: Exception) { } finally { if (canvas != null) holder.unlockCanvasAndPost(canvas) }
        }
        private fun drawFish(c: Canvas, f: Fish) {
            val x = f.x * w; val y = f.y * h; val s = f.size * min(w, h)
            val dir = if (f.fleeX < -0.02f) -1f else if (f.fleeX > 0.02f) 1f else if (cos(f.phase * 0.55f) < 0) -1f else 1f
            c.save(); c.translate(x, y); c.scale(dir, 1f)
            paint.style = Paint.Style.FILL; paint.color = f.color
            val body = RectF(-s * 0.65f, -s * 0.32f, s * 0.55f, s * 0.32f)
            c.drawOval(body, paint)
            val tail = Path().apply { moveTo(-s * 0.55f, 0f); lineTo(-s * 1.05f, -s * 0.4f); lineTo(-s * 0.98f, s * 0.4f); close() }
            c.drawPath(tail, paint)
            paint.color = 0x66FFFFFF; c.drawOval(RectF(-s * 0.18f, -s * 0.25f, s * 0.25f, s * 0.22f), paint)
            paint.color = Color.WHITE; c.drawCircle(s * 0.34f, -s * 0.08f, max(1.8f, s * 0.09f), paint)
            paint.color = Color.BLACK; c.drawCircle(s * 0.37f, -s * 0.08f, max(1f, s * 0.045f), paint)
            c.restore()
        }
    }
}
