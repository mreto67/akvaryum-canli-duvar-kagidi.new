package com.example.akvaryum

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val ink = Color.rgb(234, 248, 255)
    private val muted = Color.rgb(165, 202, 219)
    private val teal = Color.rgb(56, 211, 205)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 22, 38)
        window.navigationBarColor = Color.rgb(3, 22, 38)
        window.decorView.systemUiVisibility = 0

        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(4, 42, 62), Color.rgb(3, 19, 34), Color.rgb(2, 14, 27))
            )
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }

        page.addView(label("A Q U A R I U M  •  L I V E", teal, 11f, true))
        page.addView(space(dp(12)))
        page.addView(label("Canlı Akvaryum", ink, 31f, true))
        page.addView(label("Ekranında yaşayan bir su altı dünyası.", muted, 15f, false).apply {
            setPadding(0, dp(8), 0, dp(20))
        })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(Color.argb(100, 28, 111, 137), dp(22), Color.argb(90, 105, 224, 229))
        }
        hero.addView(label("🐠   TROPİKAL AKVARYUM", ink, 16f, true))
        hero.addView(label("Gerçekçi akvaryum görseli, renkli balıklar, yumuşak ışık huzmeleri ve yükselen hava kabarcıkları.", muted, 14f, false).apply {
            setPadding(0, dp(12), 0, 0)
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        page.addView(hero)
        page.addView(space(dp(18)))
        page.addView(label("ETKİLEŞİMLİ ÖZELLİKLER", teal, 11f, true))
        page.addView(space(dp(10)))

        val features = listOf(
            Triple("✦", "Doğal balık hareketleri", "Balıklar farklı hızlarda ve yönlerde yüzer."),
            Triple("◎", "Dokun ve izle", "Ekrana dokununca yakındaki balıklar hızla uzaklaşır."),
            Triple("◉", "Su halkaları", "Dokunduğun noktada genişleyen, ışıklı dalgalar oluşur."),
            Triple("⌁", "Su altı atmosferi", "Hareketli kabarcıklar ve hafif ışık efektleri sahneye derinlik katar.")
        )
        features.forEach { (symbol, title, description) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13))
                background = rounded(Color.argb(55, 116, 180, 201), dp(16), Color.argb(35, 180, 230, 242))
            }
            val icon = label(symbol, teal, 23f, true).apply { gravity = Gravity.CENTER; width = dp(38) }
            val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            copy.addView(label(title, ink, 14f, true))
            copy.addView(label(description, muted, 12f, false).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(icon)
            row.addView(copy, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(9)
            page.addView(row, params)
        }

        page.addView(space(dp(12)))
        val applyButton = Button(this).apply {
            text = "Canlı duvar kâğıdını ayarla"
            textSize = 15f
            setTextColor(Color.rgb(3, 30, 43))
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(teal, dp(16), teal)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { openWallpaperPicker() }
        }
        page.addView(applyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)))
        page.addView(label("Önizleme ekranında duvar kâğıdına dokunarak etkileşimi deneyebilirsin.", muted, 12f, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(13), dp(8), 0)
        })
        setContentView(scroll)
    }

    private fun openWallpaperPicker() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this@MainActivity, AquariumWallpaperService::class.java)
            )
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), strokeColor)
    }
}
