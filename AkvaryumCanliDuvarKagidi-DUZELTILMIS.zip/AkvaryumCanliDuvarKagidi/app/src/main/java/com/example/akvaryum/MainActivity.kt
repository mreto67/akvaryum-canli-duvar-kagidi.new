package com.example.akvaryum

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF062B3D.toInt())
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "🐠  Canlı Akvaryum"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "Balıklar ekranda yüzer. Canlı duvar kâğıdını önizlemede ekrana dokunarak balıkları kaçırabilir, ardından ana ekranına uygulayabilirsin."
            textSize = 16f
            setTextColor(0xFFD8F4F5.toInt())
            setPadding(0, pad, 0, pad)
        }
        val button = Button(this).apply {
            text = "Canlı duvar kâğıdını ayarla"
            setOnClickListener {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, AquariumWallpaperService::class.java))
                }
                startActivity(intent)
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
